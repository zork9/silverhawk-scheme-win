This is a small scheme (the language) shell + dlls.

run 'silverhawk-schemevm.ex -i initial.image-32' in the windows command 
prompt or write a batch script for it
