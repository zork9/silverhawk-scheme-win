/*
 * Part of Scheme 48 1.9.  See file COPYING for notices and license.
 *
 * Authors: Richard Kelsey, Jonathan Rees
 */

#include <stdlib.h>

char	**s48_bogus_environ = NULL;
