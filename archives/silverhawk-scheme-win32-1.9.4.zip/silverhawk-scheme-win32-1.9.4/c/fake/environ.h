/*
 * Part of Scheme 48 1.9.  See file COPYING for notices and license.
 *
 * Authors: Richard Kelsey, Jonathan Rees
 */

#if ! defined(ENVIRON_NAME)

#define ENVIRON_NAME	s48_bogus_environ

#endif

