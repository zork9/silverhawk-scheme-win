/*
 * Part of Scheme 48 1.9.  See file COPYING for notices and license.
 *
 * Authors: Richard Kelsey, Jonathan Rees
 */

#define PSTRUE  (0 == 0)

#define PSFALSE (0 == 1)

#define	psbool  char		/* boolean type */
